!
!  Include file for Fortran use of the FAS nonlinear solvers in PETSc
!
#if !defined (__PETSCSNESFASDEF_H)
#define __PETSCSNESFASDEF_H

#include "petsc/finclude/petscsnesdef.h"

#define SNESFASType PetscEnum

#endif
